<div class="section" id="section4">
      <div class="blog container">
        <div class="titles">
          <h1>Blog </h1>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-4">
            <div class="wrapper">
            
              <a href="#" class="card-blog">
                <div class="card__inner">
                  <img
                    data-src="https://img.newatlas.com/telehuman-holo-1.jpg?auto=format%2Ccompress&ch=Width%2CDPR&fit=crop&h=347&q=60&rect=0%2C0%2C1799%2C1012&w=616&s=db7efc68812e83dc5fe17b4582450dd9"
                    class="card_img">
                  <div class="card__content">
                    <h2 class="card__subtitle">Categoria</h2>
                    <h1 class="card__title">
                      Portable holographic projector
                    </h1>
                    <div class="card__description">
                      <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                        tempor incididunt ut labore et dolore magna aliqua...
                      </p>
                    </div>
                  </div>
                </div>
              </a>
            </div>
          </div>
        </div>
      </div>
      <div class="blog-btn">
        <a href="#" class="cta">
          <span>See More</span>
          <i class="fa fa-arrow-right" aria-hidden="true"></i>
        </a>
      </div>
    </div>