  <?php get_header(); ?>

    
    <?php  get_template_part('partials/banner'); ?>
    <!-- 2 -->
    <?php  get_template_part('partials/featured'); ?>
    <!-- 3 -->
    <?php  get_template_part('partials/categories'); ?>
    <!-- 4 -->
    <?php  get_template_part('partials/event'); ?>
    <!-- 5 -->
    <?php  get_template_part('partials/blog'); ?>
  
  <?php get_footer(); ?>
          <!-- Shop section end -->
          <a id="moveTo">⌃</a>