import { BoxIconElement } from './box-icon-element';

export { BoxIconElement };
export default BoxIconElement;

BoxIconElement.define();
